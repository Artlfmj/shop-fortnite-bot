//here the event starts
const Discord = require('discord.js')

module.exports = client => {
    console.log(guild)
    const embed1 = new Discord.MessageEmbed()
    .setTitle(`Merci à ${member.username}`)
    
    .setDescription(`Bienvenue ${member} dans TECHNCODE. Tu peux consulter les regles dans <#822747635965755433>. Accepte bien le reglement afin de profiter de tous nos services`)
    message.guild.channels.cache.get('828297901956399134').send(embed1)
}